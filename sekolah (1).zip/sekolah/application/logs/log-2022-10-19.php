<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-19 07:39:16 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-19 07:39:16 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-19 07:40:07 --> 404 Page Not Found: Read/2
ERROR - 2022-10-19 07:40:08 --> 404 Page Not Found: Read/3
