<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-20 00:30:52 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-20 00:30:52 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-20 02:32:59 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-20 02:32:59 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-20 08:09:27 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-20 08:09:27 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-20 12:28:01 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-20 12:28:01 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-20 23:08:26 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-20 23:08:26 --> 404 Page Not Found: Media_library/images
