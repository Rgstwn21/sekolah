<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-17 03:33:59 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) /home5/essapomy/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-17 03:33:59 --> Unable to connect to the database
ERROR - 2022-10-17 04:09:15 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) /home5/essapomy/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-17 04:09:15 --> Unable to connect to the database
ERROR - 2022-10-17 04:20:48 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'esspaomy_admin'@'localhost' (using password: YES) /home5/essapomy/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-17 04:20:48 --> Unable to connect to the database
ERROR - 2022-10-17 06:35:20 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'esspaomy_admin'@'localhost' (using password: YES) /home5/essapomy/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-17 06:35:20 --> Unable to connect to the database
ERROR - 2022-10-17 06:40:38 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-17 06:40:45 --> 404 Page Not Found: Admin/index
ERROR - 2022-10-17 06:42:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 09:17:27 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-17 09:49:27 --> 404 Page Not Found: Views/themes
ERROR - 2022-10-17 09:49:30 --> 404 Page Not Found: Views/themes
ERROR - 2022-10-17 09:49:37 --> 404 Page Not Found: Views/themes
ERROR - 2022-10-17 09:49:40 --> 404 Page Not Found: Views/themes
ERROR - 2022-10-17 09:49:58 --> 404 Page Not Found: Views/themes
ERROR - 2022-10-17 09:50:08 --> 404 Page Not Found: Views/themes
ERROR - 2022-10-17 09:50:10 --> 404 Page Not Found: Views/themes
ERROR - 2022-10-17 09:50:17 --> 404 Page Not Found: Views/themes
ERROR - 2022-10-17 09:50:22 --> 404 Page Not Found: Views/themes
ERROR - 2022-10-17 10:07:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 10:11:37 --> 404 Page Not Found: Assets/plugins
