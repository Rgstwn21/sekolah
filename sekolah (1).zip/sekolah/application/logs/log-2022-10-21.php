<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-21 04:21:53 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-21 04:21:53 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-21 04:28:25 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:28:25 --> Unable to connect to the database
ERROR - 2022-10-21 04:28:25 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:28:25 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 04:28:26 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:28:26 --> Unable to connect to the database
ERROR - 2022-10-21 04:28:26 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:28:26 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 04:28:26 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:28:28 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:28:28 --> Unable to connect to the database
ERROR - 2022-10-21 04:28:28 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:28:28 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 04:28:28 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:28:29 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:28:29 --> Unable to connect to the database
ERROR - 2022-10-21 04:28:29 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:28:29 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 04:28:29 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:28:32 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:28:32 --> Unable to connect to the database
ERROR - 2022-10-21 04:28:32 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:28:32 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 11:28:32 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:28:35 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:28:35 --> Unable to connect to the database
ERROR - 2022-10-21 04:28:35 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:28:35 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 11:28:35 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:29:09 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:09 --> Unable to connect to the database
ERROR - 2022-10-21 04:29:09 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:09 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 11:29:09 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:29:11 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:11 --> Unable to connect to the database
ERROR - 2022-10-21 04:29:11 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:11 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 11:29:11 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:29:12 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:12 --> Unable to connect to the database
ERROR - 2022-10-21 04:29:12 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:12 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 11:29:12 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:29:12 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:12 --> Unable to connect to the database
ERROR - 2022-10-21 04:29:12 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:12 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 11:29:12 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:29:13 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:13 --> Unable to connect to the database
ERROR - 2022-10-21 04:29:13 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:13 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 11:29:13 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:29:13 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:13 --> Unable to connect to the database
ERROR - 2022-10-21 04:29:13 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:13 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 11:29:13 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:29:14 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:14 --> Unable to connect to the database
ERROR - 2022-10-21 04:29:14 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:14 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 11:29:14 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:29:14 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:14 --> Unable to connect to the database
ERROR - 2022-10-21 04:29:14 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:14 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 11:29:14 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:29:15 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:15 --> Unable to connect to the database
ERROR - 2022-10-21 04:29:15 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:15 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 11:29:15 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
ERROR - 2022-10-21 04:29:16 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:16 --> Unable to connect to the database
ERROR - 2022-10-21 04:29:16 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'rekhagus_admin   '@'localhost' (using password: YES) /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2022-10-21 04:29:16 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: /opt/alt/php73/var/lib/php/session) /home5/rekhagus/public_html/sekolah/system/libraries/Session/Session.php 137
ERROR - 2022-10-21 11:29:16 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home5/rekhagus/public_html/sekolah/system/database/drivers/mysqli/mysqli_driver.php 401
