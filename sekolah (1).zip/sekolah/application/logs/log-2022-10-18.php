<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-18 04:04:31 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-18 04:23:44 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-18 14:43:53 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-18 14:43:53 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-18 14:43:55 --> 404 Page Not Found: Read/3
ERROR - 2022-10-18 14:45:39 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-18 14:45:39 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-18 14:45:44 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-18 14:45:44 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-18 14:45:48 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-18 14:45:48 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-18 14:47:06 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-18 14:47:06 --> 404 Page Not Found: Media_library/images
ERROR - 2022-10-18 15:32:14 --> 404 Page Not Found: Read/2
ERROR - 2022-10-18 22:06:16 --> 404 Page Not Found: Assets/images
